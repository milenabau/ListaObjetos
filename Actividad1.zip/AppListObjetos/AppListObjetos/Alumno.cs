﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AppListObjetos
{
     public class Alumno
    {
        public int Codigo { get; set; }
        public string Nombre { get; set; }
        public string Salario { get; set; }
        public string Caja { get; set; }
    }
}
